from flask import Flask, render_template, request
from EmotionDetection.emotion_detection import emotion_detector
app = Flask("Emotion Detector")

@app.route("/emotionDetector")
def emotion_detector_route():
    # Retrieve the text to analyze from the request arguments
    text_to_analyze = request.args.get('textToAnalyze')

    # Pass the text to the emotion_detector function and store the response
    response = emotion_detector(text_to_analyze)
    
    # Extract emotion scores from response
    anger_score = response.get('anger', 0)
    disgust_score = response.get('disgust', 0)
    fear_score = response.get('fear', 0)
    joy_score = response.get('joy', 0)
    sadness_score = response.get('sadness', 0)
    
    # Extract the emotions and score from the response
    emotions = {
        'anger': anger_score,
        'disgust': disgust_score,
        'fear': fear_score,
        'joy': joy_score,
        'sadness': sadness_score
    }
    
    dominant_emotion = max(emotions, key=emotions.get)
    emotions['dominant_emotion'] = dominant_emotion

    # Return the response dictionary as JSON
    return jsonify(response)

    # Return formatted string
    return (
        f"For the given statement, the system response is 'anger': {anger_score}, "
        f"'disgust': {disgust_score}, 'fear': {fear_score}, 'joy': {joy_score} "
    )

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        input_text = request.form.get("input_text", "")
        result = emotion_detector(input_text)
        return render_template("index.html", result=result)
    return render_template("index.html")    

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
